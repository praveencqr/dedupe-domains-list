A simple Python application to remove duplicate domains list from huge files.

The program can easily handle up to files with 50M lines
